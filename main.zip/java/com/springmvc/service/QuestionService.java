package com.springmvc.service;

public interface QuestionService {

}
