package com.springmvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springmvc.domain.HospitalMember;

@Service
public class HospitalServiceImp implements HospitalService{
	

	
	
}
