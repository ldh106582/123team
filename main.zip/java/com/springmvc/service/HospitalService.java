package com.springmvc.service;

import com.springmvc.domain.HospitalMember;

public interface HospitalService {

}
