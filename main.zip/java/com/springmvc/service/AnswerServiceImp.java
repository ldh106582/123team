package com.springmvc.service;

import org.springframework.stereotype.Service;

@Service
public class AnswerServiceImp implements AnswerService{

}
