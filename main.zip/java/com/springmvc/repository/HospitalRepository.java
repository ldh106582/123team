package com.springmvc.repository;

public interface HospitalRepository {

}
