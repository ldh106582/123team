package com.springmvc.repository;

import org.springframework.stereotype.Repository;

@Repository
public class HospitalRepositoryImp implements HospitalRepository{

}
