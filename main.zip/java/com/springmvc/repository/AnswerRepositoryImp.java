package com.springmvc.repository;

import org.springframework.stereotype.Repository;

@Repository
public class AnswerRepositoryImp implements AnswerRepository{

}
