package com.springmvc.repository;

import org.springframework.stereotype.Repository;

@Repository
public class QuestionRepositoryImp implements QuestionRepository{

}
