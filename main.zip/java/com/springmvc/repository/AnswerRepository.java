package com.springmvc.repository;

public interface AnswerRepository {

}
