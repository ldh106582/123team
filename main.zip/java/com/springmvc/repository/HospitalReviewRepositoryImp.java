package com.springmvc.repository;

import org.springframework.stereotype.Service;

@Service
public class HospitalReviewRepositoryImp implements HospitalReviewRepository{

}
