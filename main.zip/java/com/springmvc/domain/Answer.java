package com.springmvc.domain;

public class Answer {
	String name; // 작성자 이름
	String context; // 댓글내용
	String registday; // 작성일
	
	public Answer() {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public String getRegistday() {
		return registday;
	}

	public void setRegistday(String registday) {
		this.registday = registday;
	}

	
	
	
}
