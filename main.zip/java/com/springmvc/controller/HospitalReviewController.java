package com.springmvc.controller;

import org.springframework.stereotype.Controller;

@Controller
public class HospitalReviewController {

}
